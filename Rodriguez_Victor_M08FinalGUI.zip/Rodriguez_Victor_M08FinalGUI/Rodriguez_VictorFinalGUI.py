#Victor Rodriguez
#SDEV 153
#this GUI will allow people to select from a few items, add and remove in order to determine how many they want. At the end, the GUI will display a summary screen for the items and their price.

from breezypythongui import EasyFrame
from tkinter import PhotoImage
from tkinter.font import Font

class summaryWindow(EasyFrame):
    def __init__(self, tacoNumber, burritoNumber, enchiladaNumber, tacoDinnerNumber, burritoDinnerNumber, enchiladaDinnerNumber): #this window opens when the 'Order' buttonn is pressed. This imports the values for the amounts of each food items.
        EasyFrame.__init__(self, title="Order Summary", width=400, height=300)
        
        #here all the totals are mutiplied and/or added in order to get the price of each item. then we calculate the tax and order total.
        tacoTotal=(tacoNumber*2)
        burritoTotal=(burritoNumber*7)
        enchiladaTotal=(enchiladaNumber*3)
        tacoDinnerTotal=(tacoDinnerNumber*10)
        burritoDinnerTotal=(burritoDinnerNumber*12)
        enchiladaDinnerTotal=(enchiladaDinnerNumber*12)
        taxesAreTheft=((tacoTotal+burritoTotal+enchiladaTotal+tacoDinnerTotal+burritoDinnerTotal+enchiladaDinnerTotal)*0.07)
        mealTotal=taxesAreTheft+(tacoTotal+burritoTotal+enchiladaTotal+tacoDinnerTotal+burritoDinnerTotal+enchiladaDinnerTotal)

        #from here below we organize the information displayed in the order of 'item name', 'item number' and 'item total price' that was calculated above.
        self.addLabel(text="Order Summary", row=0, column=0)
        self.addLabel(text="Quantity", row=0, column=1)
        self.addLabel(text="Price", row=0, column=2)

        self.addLabel(text="Tacos", row=1, column=0)
        self.addLabel(text=str(tacoNumber), row=1, column=1)
        self.addLabel(text=str(tacoTotal), row=1, column=2)

        self.addLabel(text="Burritos", row=2, column=0,)
        self.addLabel(text=str(burritoNumber), row=2, column=1)
        self.addLabel(text=str(burritoTotal), row=2, column=2)

        self.addLabel(text="Enchiladas", row=3, column=0)
        self.addLabel(text=str(enchiladaNumber), row=3, column=1)
        self.addLabel(text=str(enchiladaTotal), row=3, column=2)

        self.addLabel(text="Taco Dinner", row=4, column=0)
        self.addLabel(text=str(tacoDinnerNumber), row=4, column=1)
        self.addLabel(text=str(tacoDinnerTotal), row=4, column=2)

        self.addLabel(text="Burrito Dinner", row=5, column=0)
        self.addLabel(text=str(burritoDinnerNumber), row=5, column=1)
        self.addLabel(text=str(burritoDinnerTotal), row=5, column=2)

        self.addLabel(text="Enchilada Dinner", row=6, column=0)
        self.addLabel(text=str(enchiladaDinnerNumber), row=6, column=1)
        self.addLabel(text=str(enchiladaDinnerTotal), row=6, column=2)

        #here we then top off the order summary by displaying the tax calculated above.
        self.addLabel(text="Tax", row=7, column=1)
        self.addLabel(text=str(taxesAreTheft), row=7, column=2)

        #with this the order total is added up with the tax and displayed.
        self.addLabel(text="Total", row=8, column=1)
        self.addLabel(text=str(mealTotal), row=8, column=2)

        #imageLabel = self.addLabel (text ="", row=9, column=2)  # meant to add an image below order total. This one thanking people for their order.
        #self.image = PhotoImage(file = "thanks.jpg")
        #imageLabel["image"]=self.image

class TacoTuesday(EasyFrame): #this makes a window pop up and display a limited menu due to staffing issues.

    def __init__(self):
        EasyFrame.__init__(self, width=850, height=550, title="Taco Time Ordering Service")
        
        #We do the same process for each item, initialize the 'self.itemNumber' variable and then in a single row we add an output field that shows how much of that item there is.
        self.tacoNumber=0
        self.addLabel(text="Menu", row=0, column=1)
        self.addLabel(text="Tacos     $2.00", row=1, column=0)            #For every item we display the name and the price.
        self.addButton(text="Add item", row=1, column=2, columnspan=2, command=self.addTaco)                 #The two buttons right of the output field then run a command that either removes or adds 1 from 'tacoNumber'
        self.addButton(text="Remove", row=1, column=3, columnspan=2, command=self.removeTaco)                               
        self.outputFieldTaco = self.addFloatField(value="0.0", row=1, column=1, width=8, precision=2, state="readonly")  #this is the output field. it is a read only in order to ensure there is only number values in here.

        self.burritoNumber=0
        self.addLabel(text="Burritos     $7.00", row=2, column=0,)
        self.addButton(text="Add item", row=2, column=2, columnspan=2, command=self.addBurrito)              #Every item gets their own ouput field and buttons that are made to ONLY modify their respective variable. In this case it'd be 'burritoNumber'
        self.addButton(text="Remove", row=2, column=3, columnspan=2, command=self.removeBurrito)
        self.outputFieldBurrito = self.addFloatField(value="0.0", row=2, column=1, width=8, precision=2, state="readonly")

        self.enchiladaNumber=0
        self.addLabel(text="Enchiladas     $3.00", row=3, column=0)
        self.addButton(text="Add item", row=3, column=2, columnspan=2, command=self.addEnchilada)
        self.addButton(text="Remove", row=3, column=3, columnspan=2, command=self.removeEnchilada)
        self.outputFieldEnchilada = self.addFloatField(value="0.0", row=3, column=1, width=8, precision=2, state="readonly")

        self.addLabel(text="Dinners", row=4, column=1)
        self.addLabel(text="All dinners come with rice and beans.", row=5, column=1)  #you'd be surprised how many people will still ask if the dinner comes with rice and beans.
        self.tacoDinnerNumber=0
        self.addLabel(text="Taco Dinner     $10.00", row=6, column=0)
        self.addButton(text="Add item", row=6, column=2, columnspan=2, command=self.addTacoDinner)
        self.addButton(text="Remove", row=6, column=3, columnspan=2, command=self.removeTacoDinner)
        self.outputFieldTacoDinner = self.addFloatField(value="0.0", row=6, column=1, width=8, precision=2, state="readonly")

        self.burritoDinnerNumber=0
        self.addLabel(text="Burrito Dinner     $12.00", row=7, column=0)
        self.addButton(text="Add item", row=7, column=2, columnspan=2, command=self.addBurritoDinner)
        self.addButton(text="Remove", row=7, column=3, columnspan=2, command=self.removeBurritoDinner)
        self.outputFieldBurritoDinner = self.addFloatField(value="0.0", row=7, column=1, width=8, precision=2, state="readonly")

        self.enchiladaDinnerNumber=0
        self.addLabel(text="Enchilada Dinner     $12.00", row=8, column=0)
        self.addButton(text="Add item", row=8, column=2, columnspan=2, command=self.addEnchiladaDinner)
        self.addButton(text="Remove", row=8, column=3, columnspan=2, command=self.removeEnchiladaDinner)
        self.outputFieldEnchiladaDinner = self.addFloatField(value="0.0", row=8, column=1, width=8, precision=2, state="readonly")

        #with this button we send the order with a command.
        self.addButton(text="Send Order", row=9, column=1, columnspan=2, command=self.summary)

        #imageLabel = self.addLabel (text ="", row=10, column=1)  #meant to add a cool, well drawn image below submit button.
        #self.image = PhotoImage(file = "HappyTaco.png")
        #imageLabel["image"]=self.image
    
    #open up the summary window with the item amounts being sent to the window.
    def summary(self):
        summary_window = summaryWindow(self.tacoNumber, self.burritoNumber, self.enchiladaNumber, self.tacoDinnerNumber, self.burritoDinnerNumber, self.enchiladaDinnerNumber)
        summary_window.mainloop()
        
    #these are the commands that a button is executing. so each add item adds 1 item to the variable assigned to it.
    def addTaco(self):
        self.tacoNumber += 1
        self.outputFieldTaco.setNumber(self.tacoNumber)
    
    #the remove item buttons also do what they imply. removing 1 from the variable assigned to it but only when there is at least 1 item.
    def removeTaco(self):
        if self.tacoNumber > 0:
            self.tacoNumber -= 1
            self.outputFieldTaco.setNumber(self.tacoNumber)

    def addBurrito(self):
        self.burritoNumber += 1
        self.outputFieldBurrito.setNumber(self.burritoNumber)
    
    def removeBurrito(self):
        if self.burritoNumber > 0:
            self.burritoNumber -= 1
            self.outputFieldBurrito.setNumber(self.burritoNumber)
    
    def addEnchilada(self):
        self.enchiladaNumber += 1
        self.outputFieldEnchilada.setNumber(self.enchiladaNumber)

    def removeEnchilada(self):
        if self.enchiladaNumber > 0:
            self.enchiladaNumber -= 1
            self.outputFieldEnchilada.setNumber(self.enchiladaNumber)
    
    def addTacoDinner(self):
        self.tacoDinnerNumber += 1
        self.outputFieldTacoDinner.setNumber(self.tacoDinnerNumber)
    
    def removeTacoDinner(self):
        if self.tacoDinnerNumber > 0:
            self.tacoDinnerNumber -= 1
            self.outputFieldTacoDinner.setNumber(self.tacoDinnerNumber)

    def addBurritoDinner(self):
        self.burritoDinnerNumber += 1
        self.outputFieldBurritoDinner.setNumber(self.burritoDinnerNumber)
    
    def removeBurritoDinner(self):
        if self.burritoDinnerNumber > 0:
            self.burritoDinnerNumber -= 1
            self.outputFieldBurritoDinner.setNumber(self.burritoDinnerNumber)

    def addEnchiladaDinner(self):
        self.enchiladaDinnerNumber += 1
        self.outputFieldEnchiladaDinner.setNumber(self.enchiladaDinnerNumber)

    def removeEnchiladaDinner(self):
        if self.enchiladaDinnerNumber > 0:
            self.enchiladaDinnerNumber -= 1
            self.outputFieldEnchiladaDinner.setNumber(self.enchiladaDinnerNumber)


def main():                                 
    TacoTuesday().mainloop()

if __name__ =="__main__":
    main()